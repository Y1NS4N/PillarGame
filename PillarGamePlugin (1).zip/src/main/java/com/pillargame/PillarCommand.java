
package com.pillargame;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class PillarCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.GREEN + "Comandi disponibili: create, start, end, statistiche...");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create":
                // /pillar create arena <nome>
                sender.sendMessage(ChatColor.YELLOW + "Comando 'create' eseguito.");
                break;
            case "start":
                sender.sendMessage(ChatColor.YELLOW + "Partita avviata.");
                break;
            case "end":
                sender.sendMessage(ChatColor.RED + "Partita terminata.");
                break;
            case "statistiche":
                sender.sendMessage(ChatColor.AQUA + "Statistiche giocatore.");
                break;
            default:
                sender.sendMessage(ChatColor.RED + "Comando non riconosciuto.");
                break;
        }

        return true;
    }
}
