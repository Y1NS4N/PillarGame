
package com.pillargame;

import org.bukkit.plugin.java.JavaPlugin;

public class PillarGame extends JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("PillarGame plugin attivato.");
        getCommand("pillar").setExecutor(new PillarCommand());
    }

    @Override
    public void onDisable() {
        getLogger().info("PillarGame plugin disattivato.");
    }
}
